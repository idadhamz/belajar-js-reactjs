import React from 'react'

const Todo = (props) => (
  <div>{props.description}</div>
)

export default Todo