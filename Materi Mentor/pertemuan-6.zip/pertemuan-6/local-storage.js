

// const user = {
//     name: 'Randy',
//     age: 21
// }

// const userJson = JSON.stringify(user);
// // console.log(user)

// // set item
// localStorage.setItem('user', userJson)

// const getUser = localStorage.getItem('user')
// const user = JSON.parse(getUser);
// console.log(user)
// console.log(`${getUser.name} is ${getUser.age}`)
