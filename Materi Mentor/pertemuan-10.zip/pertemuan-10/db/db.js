const todos = [
  {
    id: 1,
    title: 'makan pagi',
    description: 'saya harus sarapan pagi'
  }
]

module.exports = todos