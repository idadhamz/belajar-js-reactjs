console.log('Starting Note.js')

module.exports.addNote = () => {
  console.log('Add Note')
  return 'new Note'
}

module.exports.add = (a, b) => {
  return a + b
}

// module.export = addNote
